#include <stdio.h>
#include <sys/time.h>
#include "myThread.h"
#include "tgetElapsedTime.h"
#include <stdint.h>


/**
 * Forward declaration of our test functions
 */
void* testfunc1(void*);

/**
 *  Part A requires implementing support for true parallelism
 */
int main()
{
    // make room for a bunch of uthreads
    THREAD_T tid[32] = {1,2,3,4,5};

    // Test #1: how long does it take for one thread to run?
    uint64_t t1 = getElapsedTime();
    THREAD_CREATE(&tid[0], testfunc1, NULL);
    THREAD_JOIN(tid[0], NULL);
    uint64_t t2 = getElapsedTime();
    printf("Time for 1 thread:  %lld\n", t2-t1);

    // Test #2: how long does it take for four threads to run?
    uint64_t t3 = getElapsedTime();
    int i;
    for (i = 0; i < 4; ++i) {
        THREAD_CREATE(&tid[i], testfunc1, NULL);
    }
    for (i = 0; i < 4; ++i) {
        THREAD_JOIN(tid[i], NULL);
    }
    uint64_t t4 = getElapsedTime();
    printf("Time for 4 threads: %lld\n", t4-t3);
}

/**
 *  Increment a counter that is in a cache line on my stack
 */
void* testfunc1(void* params)
{
    volatile int counter = 0;
    int i;
    for (i = 0; i < 1024*1024*32; ++i)
        ++ counter;
    return NULL;
}
/*
void* testfunc1(void* params)
{
    while(1){
        printf("%d\n",uthread_self());
        if(uthread_self() == 2) uthread_join(1,NULL);
        if(uthread_self() == 3) return NULL;
        sleep(1);
    }
}
*/
