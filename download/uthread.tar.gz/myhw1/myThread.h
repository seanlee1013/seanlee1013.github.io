#include <unistd.h>
#include <cstdlib>
#include <setjmp.h>
#include <cstdio>
#include <signal.h>
#include <sys/time.h>
#include <string.h>

#define THREAD_CREATE uthread_create
#define THREAD_JOIN uthread_join
#define THREAD_T unsigned
#define INTERVAL 100
#define STACKSIZE 8192


int uthread_create(unsigned* t, void* (*start)(void*), void* args);
int uthread_join(unsigned t, void** status);
void uthread_exit(void* val_ptr);
int uthread_self();
void uthread_yield();
void signal_handler(int i);
void initTimer();
unsigned scheduler();
unsigned getFree();
