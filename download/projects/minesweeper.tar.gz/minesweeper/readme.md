test1: uncover a bomb 
test2: flag a flaged position
test3: uncover a uncovered position
test4: set a bomb which is not inside the grid
test5: define a grid which is larger than 100
test6: uncover a position which is not inside the grid
test7: flag a position which is not inside the grid
test8: flag more than 10 flags
test9: flag a uncovered position
test10: uncover a flaged position
test11: win steps
test12: input negative numbers
