#include <stdio.h>
#include <string.h>
#define MAX 110
int width, height;
int grid[MAX][MAX];// -1 for bomb
int state[MAX][MAX]; //0 for covered, 1 for uncovered, 2 for flaged
int numFlag = 0, numUncovered = 0;

int inarea(int x, int y){
    return (x >= 0 && x < width && y >= 0 && y < height);
}

int getState(int x,int y){
    if(state[y][x] == 0) return '*';
    if(state[y][x] == 1) return grid[y][x] + '0';
    return 'f';
}

void drawGrid(){
    int i,j;
    printf("+");
    for(i = 0;i < width;++ i) printf("-");
    printf("+\n");
    for(i = 0;i < height;++ i){
        printf("|");
        for(j = 0;j < width;++ j){
            printf("%c",getState(j,i));
        }
        printf("|\n");
    }
    printf("+");
    for(i = 0;i < width;++ i) printf("-");
    printf("+\n");

}

int setBomb(int x,int y){
    grid[y][x] = -1;
    int dir[8][2] = {{0,-1},{1,-1},{1,0},{1,1},{0,1},{-1,1},{-1,0},{-1,-1}};
    int i,tx,ty;
    for(i = 0;i < 8;++ i){
        tx = x + dir[i][0];
        ty = y + dir[i][1];
        if(inarea(tx, ty) && grid[ty][tx] != -1)
            grid[ty][tx] ++;
    }
    return 0;
}

int init(){
    char type;
    memset(grid, 0, sizeof(grid));
    memset(state, 0, sizeof(state));
    scanf("%c %d %d", &type, &width, &height);
    getchar(); //get the \n

    if(width * height < 10 || width > 99 || height > 99 || width < 0 || height < 0) return -1; 
    printf("%c %d %d\n",type, width, height);

    int x,y,i;
    for(i = 0;i < 10;++ i){
        scanf("%c %d %d",&type, &x, &y);
        getchar(); //get the \n
        if(inarea(x,y)) setBomb(x,y);// set as bomb
        else return -1;
        printf("%c %d %d\n",type, x, y);
    }
    drawGrid();
    return 0;
}

int setFlag(int x,int y){
    if(!state[y][x]){ //covered
        if(numFlag < 10){ //number of flag less than 10
            numFlag ++;
            state[y][x] = 2;
            return 0;
        }
    }
    return -1;
}

int setUncover(int x,int y){
    if(!state[y][x]){ //covered
        if(grid[y][x] == -1) return -2;
        state[y][x] = 1;
        numUncovered ++;
        return 0;
    }
    return -1;
}

int finished(){
    return numFlag + numUncovered >= width * height;
}

int main(){
    if(init() != 0){
        printf("error\n");
        return 0;
    }
    char type;
    int x,y;
    while(!finished()){
        scanf("%c %d %d",&type, &x, &y);
        getchar();
        if(!inarea(x,y)) {
            printf("error\n");
            return 0;
        }
        if(type == 'f') {
            if(setFlag(x,y) == -1){
                printf("error\n");
                return 0;
            } 
        }else if(type == 'u') {
            if(setUncover(x,y) == -1) {
                printf("error\n");
                return 0;
            }else if(setUncover(x,y) == -2) {
                printf("lost\n");
                return 0;
            }
        }else{
            printf("error\n");
            return 0;
        }
        printf("%c %d %d\n",type, x, y);
        drawGrid();
    }
    printf("won\n");
    return 0;
}
